You can use my icons for free!
But credits on me :)

Check my other works here: http://whimsy3sh.deviantart.com/

Thanks! <3